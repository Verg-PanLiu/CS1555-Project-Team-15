import java.util.Properties;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList; 
public class FlightReservation {
    public int c_id;
    Pattern VALID_TIME_REGEX; 
    public FlightReservation()
    {
        c_id = 100000000;
        VALID_TIME_REGEX = Pattern.compile("[0-2][0-9]:[0-5][0-9]", Pattern.CASE_INSENSITIVE);
    }


    public void admin_task1(Statement st)throws SQLException, ClassNotFoundException{
        if (clear_database(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The task has been completed. \u221A \u221A \u221A \u221A");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to delete all the tuples. * * * * *");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }


    public void admin_task2(Statement st)throws SQLException, ClassNotFoundException{
        if (load_airline(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The information of airline has been successfully loaded. \u221A \u221A \u221A \u221A");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to load the airline information. * * * * *");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }


    public void admin_task3(Statement st)throws SQLException, ClassNotFoundException{
        if (load_schedule(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The information of schedule has been successfully loaded. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to load the schedule information. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }
    public void admin_task4(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        if (load_price(st, conn)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The information of price has been successfully loaded. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to load the price information. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }
    public void admin_task5(Statement st)throws SQLException, ClassNotFoundException{
        if (load_plane(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The information of plane has been successfully loaded. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to load the plane information. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }
    public void admin_task6(Statement st)throws SQLException, ClassNotFoundException{
        if (list_passenger(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The list of list passenger has been successfully loaded. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to load the passenger list. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }
    public void admin_task7(Statement st)throws SQLException, ClassNotFoundException{
        if (update_time(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The current date and time has been successfully updated. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to update the current date and time. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");
    }  

    public void cust_task1(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        if (add_customer_info(st, conn)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The customer information has been successfully added. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to add the customer information. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");    
    }
    public void cust_task2(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        if (show_customer_info(st, conn)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The customer information has been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the customer information. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");    
    }
    public void cust_task3(Statement st, Connection conn)throws SQLException, ClassNotFoundException{       
        if (getPriceFromAB(st,conn)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The price between two cities have been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the price between two cities. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");        
    }
    public void cust_task4(Statement st)throws SQLException, ClassNotFoundException{
        if (find_routes(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A All routes have been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the routes. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");    
    }
    public void cust_task5(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        if (find_routes_given_flight(st,conn)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The all routes between two cities of a given airline have been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the routes. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");      
    }
    public void cust_task6(Statement st)throws SQLException, ClassNotFoundException{
        if (findAllRoutes(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A All routes with available seats between two cities on given date have been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the routes. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");      
    }
    public void cust_task7(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        if (add_reservation(st, conn)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The reservation has been successfully added. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to add the reservation. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");        
    }
    public void cust_task8(Statement st)throws SQLException, ClassNotFoundException{
        if (delete_reservation(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The reservation has been successfully deleted. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to delete the reservation. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");    
    }
    public void cust_task9(Statement st)throws SQLException, ClassNotFoundException{
        if (show_reservation(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The reservation information has been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the reservation information. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");    
    }
    public void cust_task10(Statement st)throws SQLException, ClassNotFoundException{
        if (buy_ticket(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The purchase has been successfully completed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to process purcahase. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");       
    }
    public void cust_task11(Statement st)throws SQLException, ClassNotFoundException{
        if (find_topk_customer(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The top-k customers have been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the top-k customers. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");     
    }
    public void cust_task12(Statement st)throws SQLException, ClassNotFoundException{
        if (find_topk_traveled_customer(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The top-k traveled customers have been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the top-k traveled customers. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");      
    }
    public void cust_task13(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        if (rank_airline(st)){
            System.out.println();
            System.out.println("\u221A \u221A \u221A \u221A The rank of airline has been successfully displayed. \u221A \u221A \u221A \u221A ");
        }else{
            System.out.println();
            System.out.println("* * * * * System fails to display the rank of airlines. * * * * * ");
        }
        System.out.println();
        System.out.println("------------------------------------------------------------------------------");    
    }


    public boolean add_reservation(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                               Customer Task 7: Add the Reservation                            ");

        String c_ID;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your customer ID:");
            c_ID = scanner.nextLine();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM CUSTOMER WHERE cid = CAST (? AS INTEGER);");
            stmt.setString(1, c_ID);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                break; 
            }else{
                System.out.println();
                System.out.println("    The customer does not exist.");               
            }                
        }

        String current_date;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the current date (MM/dd/yyyy):");
            current_date = scanner.nextLine();

            DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

            format.setLenient(false);
            try {
                format.parse(current_date);
                break;
            } catch (ParseException e) {
                System.out.println();
                System.out.println("    Date " + current_date + " is not valid.");
            }             
        }

        String current_time;
        String [] t;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the current time (format: HH24:MI):");
            current_time = scanner.nextLine();
            
            Matcher matcher = VALID_TIME_REGEX.matcher(current_time);
            if (matcher.find()){

            }
            else{
                System.out.println();
                System.out.println("    Invalid time format.");
                continue;
            }

            t = current_time.split(":");
            
            int time_hour = Integer.parseInt(t[0]);
            int time_min = Integer.parseInt(t[1]);

            if (time_hour > 23 || time_hour < 0){
                System.out.println();
                System.out.println("Invalid input for hour.");
                continue;                   
            }
            if (time_min > 59 || time_hour < 0){
                System.out.println();
                System.out.println("Invalid input for minute.");
                continue;                   
            }
            break;
        } 

        String [] c_d = current_date.split("/");
        String c_date = c_d[2]+"-"+c_d[0]+"-"+c_d[1];       
        String current_timestamp = c_date+" "+current_time;

        int f_num = 0;
        ArrayList<String> flight_number = new ArrayList<String>();
        ArrayList<String> depart_date = new ArrayList<String>();

        while(true){
            f_num++;
            String finished;
            while (true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Have you entered all your flights: Y/N");
                try{
                    finished = scanner.nextLine().toUpperCase();
                    if (finished.equals("Y")||finished.equals("N"))
                        break;                    
                }catch(Exception e){
                    System.out.println("Invalid input");
                }
            }

            if (finished.equals("Y"))
                break;

            String flight_num;

            while (true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Please enter your flight "+f_num+" number: ");
                flight_num = scanner.nextLine();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM FLIGHT WHERE flight_number = CAST (? AS INTEGER);");
                stmt.setString(1, flight_num);
                ResultSet res = stmt.executeQuery();
                if (res.next()) {
                    break; 
                }else{
                    System.out.println();
                    System.out.println("    The flight does not exist.");               
                }                
            }

            String departure_date;
            while (true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Please enter the departure date (MM/dd/yyyy):");
                departure_date = scanner.nextLine();

                DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

                format.setLenient(false);
                try {
                    format.parse(departure_date);
                    break;
                } catch (ParseException e) {
                    System.out.println();
                    System.out.println("    Date " + departure_date + " is not valid.");
                }
            }

            String [] d = departure_date.split("/");
            String d_date = d[2]+"-"+d[0]+"-"+d[1];
             
            try{
                boolean isTrue = st.execute("SELECT flight_seat_day_check("+flight_num+",to_date('"+d_date+"','YYYY-MM-DD'));");
                System.out.println();
                if (isTrue){
                    flight_number.add(flight_num);
                    depart_date.add(d_date);
                }else{
                    System.out.println("The flight has no seat available or the flight is not on the given day. ");
                    return false;
                }            
            }
            catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to check the flight information.");
                System.out.println();
                System.out.println(e);
                return false;
            }    
        }

        String query;

        for (int i =0; i < f_num-1; i++){
            try{
                conn.setAutoCommit(false);
                query = "CALL update_reservation_table("+c_ID+",to_timestamp('"+current_timestamp+"', 'YYYY-MM-DD HH24:MI')::timestamp without time zone);";
                st.execute(query);  
                conn.commit();         
            }
            catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to update reseravtion table.");
                System.out.println();
                System.out.println(e);
                return false;
            } 

            try{
                conn.setAutoCommit(false);
                query = "CALL update_reservation_detail("+flight_number.get(i)+",to_date('"+depart_date.get(i)+"', 'YYYY-MM-DD'),"+(i+1)+");";
                st.execute(query);
                conn.commit();           
            }
            catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to update reseravtion detail table.");
                System.out.println();
                System.out.println(e);
                return false;
            } 

            try{
                conn.setAutoCommit(false);
                query = "CALL update_price_reservation();";
                st.execute(query);   
                conn.commit();         
            }
            catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to update price table.");
                System.out.println();
                System.out.println(e);
                return false;
            }                 
        }       
        return true;
    }



    public boolean find_routes_given_flight(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("           Customer Task 5: Display all routes between two cities of a given airline           ");
        
        String departure_city;
        String arrival_city;
        String airline;
        String airline_number;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter airline name:");
            airline = scanner.nextLine();

            PreparedStatement stmt = conn.prepareStatement("SELECT airline_id FROM AIRLINE WHERE airline_name=?");
            stmt.setString(1, airline);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                // System.out.println(res.getString(1));
                airline_number = res.getString(1);
                break;
            }else{
                System.out.println("    The airline does not exist.");                
            }                
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the departure city (Three Letter Airport Code):");
            departure_city = scanner.nextLine().toUpperCase();
            if (departure_city.length() != 3) {
                System.out.println();
                System.out.println("    Invalid Airport Code.");
            }else{
                break;                
            }
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the arrival city (Three Letter Airport Code):");
            arrival_city = scanner.nextLine().toUpperCase();
            if(arrival_city.equals(departure_city)){
                System.out.println();
                System.out.println("    The arrival city cannot be the same as departure city.");
            }
            if (arrival_city.length() != 3) {
                System.out.println();
                System.out.println("    Invalid Airport Code.");
            }else{
                break;                
            }
        }

        try{
            ResultSet res = st.executeQuery("SELECT airline_direct_routes("+airline_number+",'"+departure_city+"','"+arrival_city+"');");
            System.out.println();
            System.out.println("The direct route");
            int n = 1;
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("Route "+ n +": ");
                    // System.out.println("      "+ res.getString(1));
                    String []flight_info = res.getString(1).split(",");
                    System.out.println("      Flight Number: " + flight_info[0].substring(1,flight_info[0].length()));
                    System.out.println("      " + flight_info[1]+ "      ->     "+flight_info[2]);
                    System.out.println("      " + flight_info[3]+ "      ->     "+flight_info[4].substring(0,flight_info[4].length()-1));
                    n++;
                }
            }else{
                System.out.println("The direct route does not exist. ");
            }            
        }

        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display the direct route.");
                System.out.println();
                System.out.println(e);
                return false;
        }

        try{
            ResultSet res = st.executeQuery("SELECT airline_indirect_routes("+airline_number+",'"+departure_city+"','"+arrival_city+"');");
            System.out.println();
            System.out.println("The indirect route");
            int n = 1;
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("Route "+ n +": ");
                    System.out.println("      "+res.getString(1));
                }
            }else{
                System.out.println("The indirect route does not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display the indirect route.");
                System.out.println();
                System.out.println(e);
                return false;
        }    
    return true;   
    }

    public boolean find_topk_customer(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("               Customer Task 11: Display top-k customers for each airline              ");

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the k :");
        String k = scanner.nextLine(); 

        try{
            ResultSet res = st.executeQuery("SELECT airlines_top_customer_price(a.airline_id,"+k+") FROM airline a;");
            System.out.println();
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("    " + res.getString(1));
                }
            }else{
                System.out.println("The customers do not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display top-k customers.");
                System.out.println();
                System.out.println(e);
                return false;
        }  
        return true;  
    }

    public boolean find_routes(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("               Customer Task 4: Display All Routes               ");

        String departure_city;
        String arrival_city;

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the departure city (Three Letter Airport Code):");
            departure_city = scanner.nextLine().toUpperCase();
            if (departure_city.length() != 3) {
                System.out.println();
                System.out.println("    Invalid Airport Code.");
            }else{
                break;                
            }
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the arrival city (Three Letter Airport Code):");
            arrival_city = scanner.nextLine().toUpperCase();
            if (arrival_city.length() != 3) {
                System.out.println();
                System.out.println("    Invalid Airport Code.");
            }else{
                break;                
            }
        }

        try{
            ResultSet res = st.executeQuery("SELECT direct_routes('"+departure_city+"','"+arrival_city+"');");
            System.out.println();
            System.out.println("The direct route");
            int n = 1;
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("Route "+ n +": ");
                    String []flight_info = res.getString(1).split(",");
                    System.out.println("      Flight Number: " + flight_info[0].substring(1,flight_info[0].length()));
                    System.out.println("      " + flight_info[1]+ "      ->     "+flight_info[3]);
                    System.out.println("      " + flight_info[2]+ "      ->     "+flight_info[4].substring(0,flight_info[4].length()-1));
                    n++;
                }
            }else{
                System.out.println("The direct route does not exist. ");
            }            
        }

        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display the direct route.");
                System.out.println();
                System.out.println(e);
                return false;
        }

        try{
            ResultSet res = st.executeQuery("SELECT indirect_routes('"+departure_city+"','"+arrival_city+"');");
            System.out.println();
            System.out.println("The indirect route");
            int n = 1;
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("Route "+ n +": ");
                    String []flight_info = res.getString(1).split(",");
                    System.out.println("      Flight Number: " + flight_info[0].substring(1,flight_info[0].length()));
                    System.out.println("      " + flight_info[1]+ "      ->     "+flight_info[2]);
                    System.out.println("      " + flight_info[3]+ "      ->     "+flight_info[4].substring(0,flight_info[4].length()));
                    System.out.println();
                    System.out.println("      Flight Number: " + flight_info[5].substring(0,flight_info[5].length()));
                    System.out.println("      " + flight_info[6]+ "      ->     "+flight_info[7]);
                    System.out.println("      " + flight_info[8]+ "      ->     "+flight_info[9].substring(0,flight_info[9].length()-1));
                }
            }else{
                System.out.println("The indirect route does not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display the indirect route.");
                System.out.println();
                System.out.println(e);
                return false;
        }    
        return true;                  

    } 



    public boolean find_topk_traveled_customer(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("               Customer Task 12: Display top-k traveled customers for each airline              ");

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the k :");
        String k = scanner.nextLine(); 

        try{
            ResultSet res = st.executeQuery("SELECT airline_customers_leg(a.airline_id," + k + ") FROM airline a;");
            System.out.println();
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("    " + res.getString(1));
                }
            }else{
                System.out.println("The customers do not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display top-k traveled customers.");
                System.out.println();
                System.out.println(e);
                return false;
        }  
        return true;  

    }


    public boolean rank_airline(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                            Customer Task 13: Display Rank of Airlines                          ");

        try{
            ResultSet res = st.executeQuery("SELECT airline_rank();");
            System.out.println();
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("    " + res.getString(1));
                }
            }else{
                System.out.println("The rank of airline does not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display rank of airlines.");
                System.out.println();
                System.out.println(e);
                return false;
        }  
        return true;           
    }


    public boolean buy_ticket(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                                  Customer Task 10: Buy Ticketes                                ");

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the reservation number:");
        String r_num = scanner.nextLine(); 

        try{
            String query = "CALL buy_ticket("+r_num+");";
            st.execute(query);            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to buy the tickets.");
                System.out.println();
                System.out.println(e);
                return false;
        }  
        return true;                 

    }


    public boolean show_reservation(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                        Customer Task 9: Display Reservation Information                       ");

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the reservation number:");
        String r_num = scanner.nextLine();

        try{
            ResultSet res = st.executeQuery("SELECT display_ticket_info("+r_num+");");
            System.out.println();
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("    " + res.getString(1));
                }
            }else{
                System.out.println("The reservation number does not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display reservation information.");
                System.out.println();
                System.out.println(e);
                return false;
        }  
        return true;        

    } 


    public boolean delete_reservation(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                              Customer Task 8: Delete Reservation                              ");

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the reservation number:");
        String r_num = scanner.nextLine();

        try{
            String query = "SELECT delete_reservation("+r_num+");";
            st.execute(query);            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to delete reservation.");
                System.out.println();
                System.out.println(e);
                return false;
        }  
        return true;        

    } 

    public boolean add_customer_info(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                           Customer Task 1: Add customer information                           ");

        String salutation;
        String [] name;
        String street;
        String city;
        String state; 
        String phone_number;
        String email_address;
        String credit_card;
        String credit_card_expiration_date; 
        String frequent_miles;
        Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your salutation (Mr/Mrs/Ms):");
            salutation = scanner.nextLine();

            if (salutation.equals("Mr") || salutation.equals("Mrs") || salutation.equals("Ms")){
                break;
            }else{
                System.out.println("    Invalid salutation."); 
            }        
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your name:");
            try{
                name = scanner.nextLine().split(" ");
            }catch(Exception e){
                System.out.println("Invalid name");
                continue;
            }
            

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM CUSTOMER WHERE first_name=? AND last_name=?");
            stmt.setString(1, name[0]);
            stmt.setString(2, name[1]);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                System.out.println();
                System.out.println("    The customer name has been existing.");
            }else{
                break;                
            }                
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the street you live in:");
        street = scanner.nextLine();        

        scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the city you live in:");
        city = scanner.nextLine();

        while (true){
            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the state you live in (Postal Abbreviation):");
            state = scanner.nextLine().toUpperCase();
            if (state.length() != 2) {
                System.out.println();
                System.out.println("    Invalid Postal Abbreviation");
            }else{
                break;                
            }
        }
 
        while (true){
            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your phone number:");
            phone_number = scanner.nextLine();

            if (phone_number.length() == 10){
                break;
            }else{
                System.out.println("    Invalid phone number."); 
            }        
        }

        while (true){
            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your E-mail address:");
            email_address = scanner.nextLine();
            Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email_address);
            if (matcher.find())
                break;
            else{
                System.out.println();
                System.out.println("    Invalid E-mail address.");
            }
                     
        }

        while (true){
            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your credit card number:");
            credit_card = scanner.nextLine();
            
            if (credit_card.length() != 16){
                System.out.println();
                System.out.println("    Invalid phone number.");
                continue;
            }    
                     
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM CUSTOMER WHERE credit_card_num=?");
            stmt.setString(1, credit_card);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                System.out.println();
                System.out.println("    The credit card number has been existing.");
            }else{
                break;                
            }                
        }

        while (true){
            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the card expiration date (MM/dd/yyyy):");
            credit_card_expiration_date = scanner.nextLine();

            DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

            format.setLenient(false);
            try {
                format.parse(credit_card_expiration_date);
                break;
            } catch (ParseException e) {
                System.out.println();
                System.out.println("    Date " + credit_card_expiration_date + " is not valid.");
            }             
        }
        
        String query;             
        
        while (true){
            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter your Frequent Miles:");
            frequent_miles = scanner.nextLine().toUpperCase();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM AIRLINE WHERE airline_abbreviation=?");
            stmt.setString(1, frequent_miles);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                break;
            }else{
                System.out.println();
                System.out.println("    The airline does not exist.");              
            }                
        }

        try{
            query = "SELECT add_customer("+c_id+", '"+salutation+"', '"+name[0]+"', '"+name[1]+"', '"+credit_card+"', '"+credit_card_expiration_date+"', '"+street+"','"+city+"', '"+state+"', '"+phone_number+"', '"+email_address+"', '"+frequent_miles+"');";
            st.execute(query);            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to add the customer information.");
                System.out.println();
                System.out.println(e);
                return false;
        }
        c_id--;    
        return true;
    }   

    public boolean show_customer_info(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                         Customer Task 2: Display customer information                         ");  

        String[] customer_name; 
        while (true){ 
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the customer name:");
            try{
                customer_name = scanner.nextLine().split(" ");
            }catch(Exception e){
                System.out.println("     Invalid input.");
                continue;
            }

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM CUSTOMER WHERE first_name=? AND last_name=?");
            stmt.setString(1, customer_name[0]);
            stmt.setString(2, customer_name[1]);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                break;
            }else{
                System.out.println();
                System.out.println("    The customer does not exist.");
                return false;              
            }                
        }
        
        try{
            ResultSet res = st.executeQuery("SELECT * FROM get_customer('" + customer_name[0] + "','" + customer_name[1] + "');");
            System.out.println();
            if (res.next())
            {
                System.out.println("     Customer ID: "+ res.getString(1));
                System.out.println("     Customer Name: "+res.getString(2)+"."+ res.getString(3)+" " + res.getString(4));
                System.out.println("     Credit Card Number: "+res.getString(5));
                System.out.println("     Credit Card Expiration Date: "+res.getString(6));
                System.out.println("     Address: "+res.getString(7)+", "+res.getString(8)+", "+res.getString(9));
                System.out.println("     Phone: "+res.getString(10));
                System.out.println("     E-mail: "+res.getString(11));
                System.out.println("     Frequent Miles: "+res.getString(12));
            }else{
                System.out.println("The passenger information does noy exist.");
            }
        }
        catch(SQLException e){
            System.out.println();
            System.out.println("    Unable to load the passenger information.");
            System.out.println();
            System.out.println(e.getMessage());
            return false;
        } 
        return true;            
    }




    public boolean clear_database(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                              Administrator Task 1: Erase the database                              ");
        String input;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Do you want to clear the database? ");
            System.out.println("[ENTER: Y/y] Yes");
            System.out.println("[ENTER: N/n] No");
            input = scanner.nextLine().toUpperCase();

            if (input.equals("Y")||input.equals("N")){
                break;
            }else{
                System.out.println("    Invalid Input."); 
            }        
        }

        if (input.equals("N")){
            System.out.println("    You has skipped this task.");
            return true; 
        }

        try{
            String query1 = "SELECT clear_database();";
            st.execute(query1);            
        }
        catch(Exception e){
            return false;
        } 
        return true;
    }

    public boolean load_airline(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                           Administrator Task 2: Load airline information                           ");        
        //creating File instance to reference text file in Java
        
        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the file name: ");
        String filename = scanner.nextLine();

        File text = new File(filename);
        Scanner scnr = new Scanner(System.in);

        //Creating Scanner instnace to read File in Java
        try{scnr = new Scanner(text);}
        catch(Exception e){
            System.out.println();
            System.out.println("    File does not exist.\n");
            return false;
        } 

        String query2;
        
        //Reading each line of file using Scanner class
        for(int i = 0; scnr.hasNextLine(); i++){
            String[] eachline = scnr.nextLine().split("\t");
            int num = eachline.length;
            if (num != 4){
                System.out.println();
                System.out.println("    Raw " + (i+1) + ":");
                System.out.println("    Invalid data.");
                return false;
            }

            try{
                query2 = "SELECT load_airline_info(" + eachline[0] + ", '" + eachline[1] + "', '" + eachline[2] + "', " + eachline[3] + ");";
                st.execute(query2);            
            }
            catch(SQLException e){
                    System.out.println();
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Unable to insert data of the raw into database. Please check the validation.");
                    System.out.println();
                    System.out.println(e);
                    return false;
            }              
        }
        return true;
    } 

    public boolean load_schedule(Statement st)throws SQLException, ClassNotFoundException{  
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                           Administrator Task 3: Load schedule information                          ");             
        //creating File instance to reference text file in Java

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the file name: ");
        String filename = scanner.nextLine();

        File text = new File(filename);
        Scanner scnr = new Scanner(System.in);

        //Creating Scanner instnace to read File in Java
        try{scnr = new Scanner(text);}
        catch(Exception e){
            System.out.println();
            System.out.println("    File does not exist.\n");
            return false;
        } 

        String query3;
        
        //Reading each line of file using Scanner class
        for(int i = 0; scnr.hasNextLine(); i++){
            String[] eachline = scnr.nextLine().split("\t");

            if (eachline.length != 8){
                System.out.println();
                System.out.println("    Raw " + (i+1) + ":");
                System.out.println("    Invalid data.");
                return false;
            }else{            
                int departure = Integer.parseInt(eachline[5]);
                int arrival = Integer.parseInt(eachline[6]);
                int departure_h = Integer.parseInt(eachline[5].substring(0,2));
                int departure_m = Integer.parseInt(eachline[5].substring(2,4));
                int arrival_h = Integer.parseInt(eachline[6].substring(0,2));
                int arrival_m = Integer.parseInt(eachline[6].substring(2,4));

                if (departure_h > 23 || departure_h < 0 || departure_m > 59 || departure_m < 0){
                    System.out.println();                   
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Departure time " + eachline[5] + " is not valid.");                      
                    return false;                   
                }
                if (arrival_h > 23 || arrival_m < 0 || arrival_h > 59 || arrival_m < 0){
                    System.out.println();                      
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Arrival time " + eachline[6] + " is not valid.");
                    return false;                    
                }
                if (departure >= arrival){
                    System.out.println();
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Flight time is not valid.");  
                    return false;                      
                }

                try{
                    query3 = "SELECT load_schedule_info("+eachline[0]+", "+eachline[1]+", '"+eachline[2]+"', '"+eachline[3]+"', '"+eachline[4]+"', '"+eachline[5]+"', '"+eachline[6]+"', '"+eachline[7]+"');";
                    st.execute(query3);           
                }
                catch(SQLException e){
                    System.out.println();
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Unable to insert data of the raw into database. Please check the validation.");
                    System.out.println();
                    System.out.println(e.getMessage());
                    return false;
                } 
            }                 
        }
        return true;
    } 

    public boolean load_plane(Statement st)throws SQLException, ClassNotFoundException{ 
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                            Administrator Task 5: Load plane information                            ");  

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the file name: ");
        String filename = scanner.nextLine();

        //creating File instance to reference text file in Java
        File text = new File(filename);
        Scanner scnr = new Scanner(System.in);

        //Creating Scanner instnace to read File in Java
        try{scnr = new Scanner(text);}
        catch(Exception e){
            System.out.println();
            System.out.println("    File does not exist.\n");
            return false;
        } 

        String query4;
        
        //Reading each line of file using Scanner class
        for(int i = 0; scnr.hasNextLine(); i++){
            String[] eachline = scnr.nextLine().split("\t");
            if (eachline.length != 6){
                System.out.println();
                System.out.println("    Raw " + (i+1) + ":");
                System.out.println("    Invalid data.");
                return false;
            }else{
                DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

                format.setLenient(false);
                try {
                    format.parse(eachline[3]);
                } catch (ParseException e) {
                    System.out.println();
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Date " + eachline[3] + " is not valid.");
                    return false;
                }

                try{
                    query4 = "SELECT load_plane_info('"+eachline[0]+"', '"+eachline[1]+"', "+eachline[2]+", '"+eachline[3]+"', "+eachline[4]+", "+eachline[5]+");";
                    st.execute(query4);           
                }
                catch(SQLException e){
                    System.out.println();
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Unable to insert data of the raw into database. Please check the validation.");
                    System.out.println();
                    System.out.println(e);
                    return false;
                } 
            }
                
        }
        return true;
    }

    public boolean load_price(Statement st, Connection conn)throws SQLException, ClassNotFoundException{ 
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                            Administrator Task 4: Load pricing information                            ");              
        //creating File instance to reference text file in Java
        String input;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please choose what you want to do:");
            System.out.println("[ENTER: L/l] Load pricing information");
            System.out.println("[ENTER: C/c] Change the price of an existing flight");
            input = scanner.nextLine().toUpperCase();

            if (input.equals("L")||input.equals("C")){
                break;
            }else{
                System.out.println("    Invalid Input."); 
            }        
        }

        if (input.equals("L")){ 
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the file name: ");
            String filename = scanner.nextLine();

            File text = new File(filename);
            Scanner scnr = new Scanner(System.in);

            //Creating Scanner instnace to read File in Java
            try{scnr = new Scanner(text);}
            catch(Exception e){
                System.out.println();
                System.out.println("    File does not exist.\n");
                return false;
            } 

            String query5;
            
            //Reading each line of file using Scanner class
            for(int i = 0; scnr.hasNextLine(); i++){
                String[] eachline = scnr.nextLine().split("\t");
                if (eachline.length != 5){
                    System.out.println();
                    System.out.println("    Raw " + (i+1) + ":");
                    System.out.println("    Invalid data.");
                    return false;
                }else{
                    String departure = eachline[0];
                    String arrival = eachline[1];
                    if (departure.length() != 3){
                        System.out.println();
                        System.out.println("    Raw " + (i+1) + ":");
                        System.out.println("    Invalid departure city.");  
                        return false;                      
                    }
                    if (arrival.length() != 3){
                        System.out.println();
                        System.out.println("    Raw " + (i+1) + ":");
                        System.out.println("    Invalid arrival city.");  
                        return false;                      
                    }
                    if (departure.equals(arrival)){
                        System.out.println();
                        System.out.println("    Raw " + (i+1) + ":");
                        System.out.println("    Departure city cannot be the same as arrival city.");  
                        return false;                      
                    }

                    try{
                        query5 = "SELECT load_pricing_info('"+eachline[0]+"', '"+eachline[1]+"', "+eachline[2]+", "+eachline[3]+", "+eachline[4]+");";
                        st.execute(query5);           
                    }
                    catch(SQLException e){
                        System.out.println();
                        System.out.println("    Raw " + (i+1) + ":");
                        System.out.println("    Unable to insert data of the raw into database. Please check the validation.");
                        System.out.println();
                        System.out.println(e);
                        return false;
                    } 
                }
                    
            }
             return true;
        }else{
            String departure;
            String arrival;
            String h_price;
            String l_price;  
            while(true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Please enter the departure city (three letter airport code):");
                departure = scanner.nextLine().toUpperCase();
                if(departure.length() != 3){
                    System.out.println();
                    System.out.println("The departure city you enter is invalid.");
                }
                else
                    break;
            }
            while(true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Please enter the arrival city (three letter airport code):");
                arrival = scanner.nextLine().toUpperCase();
                if(arrival.length() != 3){
                    System.out.println();
                    System.out.println("The arrival city you enter is invalid.");
                }
                else
                    break;
            }
            String query6;
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the high price:");
            h_price = scanner.nextLine();

            scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the low price:");
            l_price = scanner.nextLine();
            String id = "";


            PreparedStatement stmt = conn.prepareStatement("SELECT airline_id FROM PRICE WHERE departure_city=? AND arrival_city=?");
            PreparedStatement delete = conn.prepareStatement("DELETE FROM PRICE WHERE departure_city=? AND arrival_city=?");
            stmt.setString(1, departure);
            stmt.setString(2, arrival);
            delete.setString(1, departure);
            delete.setString(2, arrival);
            ResultSet res = stmt.executeQuery();
            delete.execute();
            if (res.next()) {
                id = res.getString("airline_id");
            }else{
                System.out.println();
                System.out.println("    The flight you enter is not existing.");
                return false;                    
            }

            try{
                st.execute("SELECT load_pricing_info('"+departure+"', '"+arrival+"', "+id+", "+h_price+", "+l_price+");"); 
            }
            catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to change the pricing information of existing flight.");
                System.out.println();
                System.out.println(e.getMessage());
                return false;
            }           
        }
        return true;
    }

    public boolean list_passenger(Statement st) throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                               Administrator Task 6: Display passengers                             "); 

        String date;
        String flight_number;

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the flight date (format: MM/DD/YYYY):");
            date = scanner.nextLine();

            DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

            format.setLenient(false);
            try {
                format.parse(date);
                break;
            } catch (ParseException e) {
                System.out.println();
                System.out.println("    Date " + date + " is not valid.");
            }             
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("Please enter the flight number:");
        flight_number = scanner.nextLine();
        String [] passenger;
        try{
            ResultSet res = st.executeQuery("SELECT list_passenger("+flight_number+", '"+date+"');");
            System.out.println();
            int n = 1; 
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    passenger = res.getString(1).split(","); 
                    System.out.print("    " + n + ". ");
                    System.out.print(passenger[0].substring(1, passenger[0].length()) + ". ");
                    System.out.print(passenger[1] + " ");
                    System.out.print(passenger[2].substring(0, passenger[2].length()-1)+"\n");
                    n++;
                }
            }else{
                System.out.println("There is no passenger who bought tickets for the given flight and the given date. ");
            }
        }
        catch(SQLException e){
            System.out.println();
            System.out.println("    Unable to load the passenger list of given flight.");
            System.out.println();
            System.out.println(e.getMessage());
            return false;
        } 
        return true;       
    }

    public boolean update_time(Statement st)throws SQLException, ClassNotFoundException{ 
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                         Administrator Task 7: Update current date and time                         ");              
 
        String date;
        String time;
        String [] t;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the current date (format: MM/DD/YYYY):");
            date = scanner.nextLine();

            DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

            format.setLenient(false);
            try {
                format.parse(date);
                break;
            } catch (ParseException e) {
                System.out.println();
                System.out.println("    Date " + date + " is not valid.");
            }             
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the current time (format: HH24:MI):");
            time = scanner.nextLine();

            Matcher matcher = VALID_TIME_REGEX.matcher(time);
            if (matcher.find()){

            }
            else{
                System.out.println();
                System.out.println("    Invalid time format.");
                continue;
            }
            
            try{
               t = time.split(":"); 
            }catch(Exception e){
               System.out.println("Invalid time format.");
               continue;
            }
            
            int time_hour = Integer.parseInt(t[0]);
            int time_min = Integer.parseInt(t[1]);

            if (time_hour > 23 || time_hour < 0){
                System.out.println();
                System.out.println("Invalid input for hour.");
                continue;                   
            }
            if (time_min > 59 || time_hour < 0){
                System.out.println();
                System.out.println("Invalid input for minute.");
                continue;                   
            }
            break; 
        }

        String timestamp = date +" "+time;
        try{
            st.execute("SELECT update_time('"+timestamp+"');"); 
        }
        catch(SQLException e){
            System.out.println();
            System.out.println("    Unable to update the current date and time.");
            System.out.println();
            System.out.println(e.getMessage());
            return false;
        } 
        return true;
    }

    public boolean getPriceFromAB(Statement st, Connection conn)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                         Customer Task 3:  Find price for flights between two cities                         ");   
        boolean flag=true;
        try{
            String frequentAir = "";
            String departureCity = "";
            String arrivalCity = "";

            while(true) {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Please enter your departure city： ");
                departureCity = scanner.nextLine().toUpperCase();
                boolean hasCheck = false;
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM FLIGHT WHERE departure_city = ?;");
                stmt.setString(1, departureCity);
                ResultSet resultSet = stmt.executeQuery();

                while(resultSet.next()){
                    if(resultSet.getString("flight_number")!=null && !"".equals(resultSet.getString("flight_number"))){
                        hasCheck=true;
                    }
                }
                if(hasCheck){
                    break;
                }
            }
            while(true) {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Please enter your arrival city: ");
                arrivalCity = scanner.nextLine().toUpperCase();
                boolean hasCheck = false;
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM FLIGHT WHERE arrival_city = ?;");
                stmt.setString(1, arrivalCity);
                ResultSet resultSet = stmt.executeQuery();

                while(resultSet.next()){
                    if(resultSet.getString("flight_number")!=null && !"".equals(resultSet.getString("flight_number"))){
                        hasCheck=true;
                    }
                }
                if(hasCheck){
                    break;
                }
            }
            List<Map<String,Object>> list = new ArrayList<>();
            List<Map<String, Object>> price1 = getPrice(st,departureCity, arrivalCity, frequentAir, conn);
            List<Map<String, Object>> price2 = getPrice(st,arrivalCity, departureCity, frequentAir, conn);
            if(price1!=null && price1.size()>0){
                System.out.println("Price from "+ departureCity +" to " + arrivalCity);
                for(Map<String,Object> map:price1){
                    System.out.println(map.get("highPrice"));
                    System.out.println(map.get("lowPrice"));
                }
            }
            if(price2!=null && price2.size()>0){
                System.out.println("Price from "+ arrivalCity + " to " + departureCity);
                for(Map<String,Object> map:price2){
                    System.out.println(map.get("highPrice"));
                    System.out.println(map.get("lowPrice"));
                }
            }

        }catch (Exception e){
            System.out.println();
            System.out.println("    Unable to find price for flights between two cities.");
            System.out.println();
            System.out.println(e.getMessage());
            flag=false;
        }finally {
            return flag;
        }

    }

    public List<Map<String,Object>> getPrice(Statement st,String departureCity,String arrivalCity,String frequentAir, Connection conn)throws Exception{
        List<Map<String,Object>> list = new ArrayList<>();

        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM PRICE WHERE departure_city = ? AND arrival_city = ?;");
        stmt.setString(1, departureCity);
        stmt.setString(2, arrivalCity);
        ResultSet resultSet = stmt.executeQuery();        
        while(resultSet.next()){
            Map<String,Object> map = new HashMap<>();
            boolean fre = false;
            String airlineID = resultSet.getString("airline_id");

            stmt = conn.prepareStatement("SELECT * FROM AIRLINE WHERE airline_id = CAST (? AS INTEGER);");
            stmt.setString(1, airlineID);
            ResultSet set = stmt.executeQuery();   
            String airname = "";
            while(set.next()){
                airname = set.getString("airline_name");
            }
            if(airname.split(" ")[0].toUpperCase().equals(frequentAir)){
                fre=true;
            }
            double high = resultSet.getInt("high_price");
            double low = resultSet.getInt("low_price");
            if(fre){
                high=0.9*high;
                low=0.9*low;
            }
            map.put("highPrice",high);
            map.put("lowPrice",low);
            list.add(map);
        }
        return list;
    }


    public boolean findAllRoutes(Statement st)throws SQLException, ClassNotFoundException{
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                         Customer Task 6:  Find all routes with available seats between two cities on given dates                         "); 

        String departure_city;
        String arrival_city;
        String date;
        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the flight date (format: MM/DD/YYYY):");
            date = scanner.nextLine();

            DateFormat format = new SimpleDateFormat("MM/dd/yyyy");

            format.setLenient(false);
            try {
                format.parse(date);
                break;
            } catch (ParseException e) {
                System.out.println();
                System.out.println("    Date " + date + " is not valid.");
            }             
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the departure city (Three Letter Airport Code):");
            departure_city = scanner.nextLine().toUpperCase();
            if (departure_city.length() != 3) {
                System.out.println();
                System.out.println("    Invalid Airport Code.");
            }else{
                break;                
            }
        }

        while (true){
            Scanner scanner = new Scanner(System.in);
            System.out.println();
            System.out.println("Please enter the arrival city (Three Letter Airport Code):");
            arrival_city = scanner.nextLine().toUpperCase();
            if(arrival_city.equals(departure_city)){
                System.out.println();
                System.out.println("    The arrival city cannot be the same as departure city.");
            }
            if (arrival_city.length() != 3) {
                System.out.println();
                System.out.println("    Invalid Airport Code.");
            }else{
                break;                
            }
        }

        try{
            ResultSet res = st.executeQuery("SELECT direct_routes_available_seats('"+departure_city+"','"+arrival_city+"',to_date('"+date+"','MM-DD-YYYY'));");
            System.out.println();
            System.out.println("The direct route");
            int n = 1;
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("Route "+ n +": ");
                    String []flight_info = res.getString(1).split(",");
                    System.out.println("      Flight Number: " + flight_info[0].substring(1,flight_info[0].length()));
                    System.out.println("      " + flight_info[1]+ "      ->     "+flight_info[2]);
                    System.out.println("      " + flight_info[3]+ "      ->     "+flight_info[4].substring(0,flight_info[4].length()-1));
                    n++;
                }
            }else{
                System.out.println("The direct route does not exist. ");
            }            
        }

        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display the direct route.");
                System.out.println();
                System.out.println(e);
                return false;
        }

        try{
            ResultSet res = st.executeQuery("SELECT indirect_routes_available_seats('"+departure_city+"','"+arrival_city+"',to_date('"+date+"','MM-DD-YYYY'));");
            System.out.println();
            System.out.println("The indirect route");
            int n = 1;
            if (res.isBeforeFirst())
            {
                while (res.next()) {
                    System.out.println("Route "+ n +": ");
                    System.out.println("      "+res.getString(1));
                }
            }else{
                System.out.println("The indirect route does not exist. ");
            }            
        }
        catch(SQLException e){
                System.out.println();
                System.out.println("    Unable to display the indirect route.");
                System.out.println();
                System.out.println(e);
                return false;
        }    
    return true;   
    }        

}    

