import java.util.Properties;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList; 
public class Driver {
    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/pal81";
        Properties props = new Properties();
        props.setProperty("user", "pal81");
        props.setProperty("password", "JACKKKnm4399()");
        
        Connection conn = DriverManager.getConnection(url, props);            
        Statement st = conn.createStatement();


        BufferedReader objReader;
        StringBuffer s = new StringBuffer("");
        try {
            String strCurrentLine;
            objReader = new BufferedReader(new FileReader("team15.sql"));

            while ((strCurrentLine = objReader.readLine()) != null) {
                s.append(strCurrentLine);
                s.append("\n");
            }
        }catch (IOException e){
            e.printStackTrace();
        }
        
        st.execute(s.toString());
        
        FlightReservation test = new FlightReservation();

        String input;
        while(true)
        {
            while (true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Please choose who you are:");
                System.out.println("[ENTER: A/a] Administrator");
                System.out.println("[ENTER: C/c] Customer");
                input = scanner.nextLine().toUpperCase();

                if (input.equals("A")||input.equals("C")){
                    break;
                }else{
                    System.out.println("    Invalid Input."); 
                }        
            }

            if (input.equals("A")){
                test.admin_task1(st);
                test.admin_task2(st);
                test.admin_task5(st);
                test.admin_task3(st);
                test.admin_task4(st, conn);

                insert_cus_data(st);

                test.admin_task6(st);
                test.admin_task7(st);                
            }else{
                test.cust_task1(st, conn);
                test.cust_task2(st, conn);
                test.cust_task3(st,conn);
                test.cust_task4(st);
                test.cust_task5(st, conn);
                test.cust_task6(st);
                test.cust_task7(st, conn);
                test.cust_task8(st);
                test.cust_task9(st);
                test.cust_task10(st);
                test.cust_task11(st);
                test.cust_task12(st);
                test.cust_task13(st, conn);            
            }

            while (true){
                Scanner scanner = new Scanner(System.in);
                System.out.println();
                System.out.println("Do you want to test it again ?");
                System.out.println("[ENTER: Y/y] Choose who you are");
                System.out.println("[ENTER: N/n] Exit the system");
                input = scanner.nextLine().toUpperCase();

                if (input.equals("Y")){
                    break;
                }else if (input.equals("N")){
                    System.exit(0);  
                }else{
                    System.out.println("Invalid Input");
                }        
            }
        }
    }

    static void insert_cus_data(Statement st)throws SQLException, ClassNotFoundException{
        BufferedReader objReader;
        StringBuffer s = new StringBuffer("");
        try {
            String strCurrentLine;
            objReader = new BufferedReader(new FileReader("team15_insert.sql"));

            while ((strCurrentLine = objReader.readLine()) != null) {
                s.append(strCurrentLine);
                s.append("\n");
            }
        }catch (IOException e){
            e.printStackTrace();
        }
        
        st.execute(s.toString()); 
        System.out.println();
        System.out.println("------------------------------Some sample customer data has been inserted------------------------------");
        System.out.println();
    }

}


